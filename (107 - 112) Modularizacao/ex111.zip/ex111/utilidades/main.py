"""
109 porem mais organizado
"""

from utilidades.dado import resumo
  
p = float(input("Valor: "))
resumo(p,10,13)